<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: Login.php");
    exit;
}

include 'profil.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Music Player</title>
    <link rel="stylesheet" href="lag.css">
</head>
<body>
    <div class="song-list">
        <?php
        $res = $conn->query("SELECT * FROM lagu ORDER BY id DESC");
        while ($row = $res->fetch_assoc()) {
            echo "
            <div class='song'>
                <a href='lagu{$row['id']}.html'><img src='Poster/{$row['cover']}' alt='' class='cover'></a>
                <div class='song-info'>
                    <div class='song-tittle'>{$row['judul']}</div>
                    <div class='song-artist'>{$row['penulis']}</div>
                </div>
                <div class='controls'>
                    <button class='loop' onclick='toggleLoop()'>Loop: OFF</button>
                </div>
                <button class='play-button' onclick=\"playSong('song{$row['id']}')\">▶️</button>
                <audio id='song{$row['id']}' src='list-lagu/{$row['audio']}'></audio>
            </div>
            ";
        }
        ?>
    </div>
<footer>
<button class="tambah-lagu" id="openAddPopup">➕ Tambah Lagu</button>
</footer>
    

    <div id="popupOverlay" class="popup-overlay">
        <div id="popupContent" class="popup-content">
            <span id="closePopup" class="close-btn">&times;</span>
            <form action="save.php" method="POST" enctype="multipart/form-data">
             <input type="text" name="judul" placeholder="Judul Lagu" required><br>

             <input type="text" name="penulis" placeholder="Penulis"><br>

                 <div class="file-upload-cover">
                <label for="coverFile">Cover Lagu</label>
                <input type="file" name="cover" id="coverFile"><br>
                <span id="coverName"></span>
                </div>
            <div class="file-upload-audio">
                <label for="audioFile">Audio Lagu</label>
                <input type="file" name="audio" id="audioFile"><br>
                <span id="audioName"></span>
            </div>
             
                <button type="submit">Upload Lagu</button>
            </form>
        </div>
    </div>
    <script>
            const openBtn = document.getElementById('openAddPopup');
            const overlay = document.getElementById('popupOverlay');
            const popup = document.getElementById('popupContent');
            const closeBtn = document.getElementById('closePopup');
            const coverInput = document.getElementById('coverFile');

        openBtn.addEventListener('click', () => {
        overlay.style.display = 'flex';
        popup.style.animation = 'popupIn 0.3s ease-out forwards';
        });

        closeBtn.addEventListener('click', () => {
        popup.style.animation = 'popup 0.3s ease-in forwards';
        setTimeout(() => {
        overlay.style.display = 'none';
        }, 300);
        });

       
        coverInput.addEventListener('change', function () {
        if (this.files && this.files[0]) {
         const reader = new FileReader();
        reader.onload = function (e) {
        let img = document.getElementById('preview-img');
        if (!img) {
          img = document.createElement('img');
          img.id = 'preview-img';
          img.style.maxWidth = '100%';
          img.style.marginTop = '10px';
          document.querySelector('.file-upload').appendChild(img);
        }
        img.src = e.target.result;
      }
      reader.readAsDataURL(this.files[0]);
    }
  });

    document.getElementById('coverFile').addEventListener('change', function() {
        const fileName = this.files[0]?.name || 'Tidak Ada File Yang Dipilih';
        document.getElementById('coverName').textContent = `📁 ${fileName}`;
    });

    document.getElementById('audioFile').addEventListener('change', function() {
        const fileName = this.files[0]?.name || 'Tidak Ada File Yang Dipilih';
        document.getElementById('audioName').textContent = `🎵 ${fileName}`;
    });
    </script>
</body>
</html>
