<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "musicplayer";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if(!$conn) {
        die ("Koneksi Dengan Database Gagal: ". mysqli_connect_error());
    }
?>