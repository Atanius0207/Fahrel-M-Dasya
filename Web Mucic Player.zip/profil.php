<?php
    include 'db.php';

    if (!isset($_SESSION['user'])) {
        header("Location: Login.php");
        exit;
    }

    $user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link rel="stylesheet" href="pro.css">
</head>
<body>
    <nav class="navbar">
    <header class="nav-title">Music Player</header>
        <div class="nav-right">
            <div class="profile-container" id="avatarBtn">
                <img class="avatar" src="avatar/avatar.png" alt="avatar">
            </div>
            <div class="dropdown" id="dropdownMenu">
                <p class="dropdown-name"><?= htmlspecialchars($user['nama_lengkap']); ?></p>
                <a href="profil.php">👤 Profil</a>
                <a href="logout.php">🚪 Logout</a>
            </div>
        </div>
    </div>
    </nav>
    <script src="profil.js"></script>
</body>
</html>