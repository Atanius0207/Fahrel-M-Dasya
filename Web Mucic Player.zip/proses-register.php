<?php
    include 'db.php';

    if(isset($_POST['register'])) {
        $username = $_POST['username'];
        $password = md5($_POST['password']);
        $nama_lengkap = $_POST['nama-lengkap'];
        $email = $_POST['email'];

        $sql = "INSERT INTO user (id, username, password, nama_lengkap, email) VALUE (null, '$username','$password' , '$nama_lengkap', '$email')";
        $query = mysqli_query($conn, $sql);

        if($query) {
            header('Location: Login.php?status=sukses');
        }
        else {
            header('Location: Register.php?status=gagal');
        }
    }
    else {
        die("Akses Dilarang...");
    }
?>