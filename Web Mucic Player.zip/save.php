<?php
    include 'db.php';

    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $cover = $_FILES['cover']['name'];
    $audio = $_FILES['audio']['name'];

    move_uploaded_file($_FILES['cover']['tmp_name'], "Poster/$cover");
    move_uploaded_file($_FILES['audio']['tmp_name'], "list-lagu/$audio");

    $conn->query("INSERT INTO lagu (id,judul, penulis, cover, audio)
                VALUES (NULL, '$judul','$penulis','$cover','$audio')");

    $id = $conn->insert_id;

    $template = file_get_contents('lagu-template.html');

    $template = str_replace('{{JUDUL}}', $judul, $template);
    $template = str_replace('{{PENULIS}}', $penulis, $template);
    $template = str_replace('{{COVER}}', "Poster/$cover", $template);
    $template = str_replace('{{AUDIO}}', "list-lagu/$audio", $template);
    $template = str_replace('{{FILENAME}}', "lagu$id.html", $template);

    file_put_contents("lagu$id.html", $template);

    header("Location: list-lagu.php");
?>