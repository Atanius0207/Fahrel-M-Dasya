<?php
    session_start();
    include 'db.php';

    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        $query = mysqli_query($conn, "SELECT * FROM user WHERE username='$username' AND password='$password'");
        $user = mysqli_fetch_assoc($query);

        if ($user) {
            $_SESSION['user'] = $user;
            header("Location: list-lagu.php");
            exit;
        }
        else {
            $error = "Username atau Password Salah!";
        }
    }
?>