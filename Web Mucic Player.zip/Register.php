<?php
    include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login2.css">
    <title>Register</title>
</head>
<body>
    <form action="proses-register.php" method="POST">
        <a href="Login.php">Login</a>
        <fieldset>
            <legend>Form Register</legend>

            <label for="username">Username: </label>
            <input type="text" id="username" name="username" placeholder="Masukkan Username" required>
            <br><br>
            <label for="password">Password: </label>
            <input type="password" id="password" name="password" placeholder="Masukkan Password" required>
            <br><br>

            <label for="nama-lengkap">Nama Lengkap: </label>
            <input type="text" id="nama-lengkap" name="nama-lengkap" placeholder="Masukkan Nama Lengkap" required>
            <br><br>

            <label for="email">Email: </label>
            <input type="text" id="email" name="email" placeholder= "Masukkan Email Anda" required>
            <br><br>
            <input type="submit" value="Register" name="register">
        </fieldset>
    </form>
</body>
</html>