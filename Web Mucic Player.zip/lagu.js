const openBtn = document.getElementById('openAddPopup');
const overlay = document.getElementById('popupOverlay');
const popup = document.getElementById('popupContent');
const closeBtn = document.getElementById('closePopup');

openBtn.addEventListener('click', () => {
    overlay.style.display = 'flex';
    popup.style.animation = 'popupIn 0.3s ease-out forwards';
});

closeBtn.addEventListener('click', () => {
    popup.style.animation = 'popup 0.3s ease-in forwards';
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 300);
});