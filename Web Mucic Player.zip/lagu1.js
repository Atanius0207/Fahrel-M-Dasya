const audio = document.getElementById('audioPlayer');
const progressBar = document.querySelector('.progress');
const loopButton = document.querySelector('button:nth-child(2)');

let isLooping = false;


function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes < 10 ? '0' + minutes : minutes}:${secs < 10 ? '0' + secs : secs}`;
}

audio.addEventListener('timeupdate', () => {
    const percent = (audio.currentTime / audio.duration) * 100;
    progressBar.style.width = percent + '%';

    const current = formatTime(audio.currentTime);
    const total = isNaN(audio.duration) ? '00:00' : formatTime(audio.duration);
    document.getElementById('timeDisplay').textContent = `${current} / ${total}`;
});

function playPause() {
    if (audio.paused) {
        audio.play();
    } else {
        audio.pause();
    }

    audio.loop = isLooping;
}

function setProgress(event) {
    const width = event.currentTarget.clientWidth;
    const clickX = event.offsetX;
    const duration = audio.duration;

    audio.currentTime = (clickX / width) * duration;
}


loopButton.addEventListener('click', () => {
    isLooping = !isLooping;
    loopButton.textContent = `Loop: ${isLooping ? 'ON' : 'OFF'}`;
    audio.loop = isLooping;
});

document.querySelector('.progress-bar').addEventListener('click', setProgress);
