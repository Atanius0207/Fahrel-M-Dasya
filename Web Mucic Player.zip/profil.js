document.addEventListener("DOMContentLoaded", function () {
    const avatarBtn = document.getElementById("avatarBtn");
    const dropdown = document.getElementById("dropdownMenu");

    avatarBtn.addEventListener("click", function (e) {
        dropdown.classList.toggle("show");
        e.stopPropagation();
    });

    window.addEventListener("click", function () {
        dropdown.classList.remove("show");
    });
});