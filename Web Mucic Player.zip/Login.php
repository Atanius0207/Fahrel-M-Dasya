<?php
    include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login2.css">
    <title>Login</title>
</head>
<body>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form action="proses-login.php" method="POST">
        <a href="Register.php">Register</a>
        <fieldset>
            <legend>Login Form</legend>

            <label for="username">Username: </label>
            <input type="text" id="username" name="username" placeholder="Masukkan Username" required>
            <br><br>

            <label for="password">Password: </label>
            <input type="password" id="password" name="password" placeholder="Masukkan Password" required>
            <br><br>
            <input type="submit" value="Login" name="login">
        </fieldset>
    </form>
</body>
</html>